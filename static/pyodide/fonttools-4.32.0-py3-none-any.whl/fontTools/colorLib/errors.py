
class ColorLibError(Exception):
    pass
